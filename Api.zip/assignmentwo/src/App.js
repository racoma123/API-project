
import React,{Component} from 'react';
import Header from './component/Header';



class App extends Component{


    render(){
      return(

      <>
      <div>
        <Header />
          

        </div>

      </>
        
      )
    }
}


export default App;
