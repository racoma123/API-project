import React, { Component } from 'react'
import {GoogleLogin } from 'react-google-login';


export class Googlelogin extends Component {

    state={
        isLoggedIn:false,
        userID:"",
        name:"",
        email:"",
        picture:""
    }
    handleLogout = () => {
        this.setState({
          isLoggedIn: false,
          userID: '',
          name: '',
          email: '',
          picture: ''
        });
      };
    render() {
        let googleContent;
        const responseGoogle=(response)=>{
           // console.log(response);
           //console.log(response.Iw.Ju.Zv);
            this.setState({
              isLoggedIn:true,
              userID:response.userID,
              name:response.name,
              email:"data"
            // userID: response.profileObj.googleId,
            // name: response.profileObj.name,
            // email: response.profileObj.email,
            // picture: response.profileObj.imageUrl
        })
        }
        if(this.state.isLoggedIn){
            console.log("Data");
            googleContent=(

                <div>

                  <h2>Welcome, {this.state.name}!</h2>
                  <img src={this.state.picture} alt="Profile" />
                  <p>Email: {this.state.email}</p>
                  <button onClick={this.handleLogout}>Logout</button>
      
                </div>
 
            )
        }else{
           googleContent=(
            <GoogleLogin
            clientId="339681351027-1801t35mfsk7fs5nb0mr7h8jbar7bmkp.apps.googleusercontent.com" //its ur client 
            buttonText="Login with Google"
            onSuccess={responseGoogle}
            onFailure={responseGoogle}
          />
           )
        }
        return (
            <div>
              {googleContent}
            </div>
        )
    }
}

export default Googlelogin
