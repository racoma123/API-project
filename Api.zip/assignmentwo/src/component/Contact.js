import React,{Component } from 'react';
import './contact.css';
import Footer from './Footer';

class Contact extends Component{
    render(){
        return(
            <>                    
                    <section class="contact_section layout_padding">
                        <div class="container">
                        <div class="d-flex flex-column align-items-end">
                            <div class="custom_heading-container">
                            <hr/>
                            <h2>
                                Contact Us
                            </h2>
                            </div>
                        </div>
                        <div class="layout_padding-top layout_padding2-bottom">
                            <div class="row">
                            <div class="col-md-7">
                                <form action="">
                                <div class="contact_form-container">
                                    <div>
                                    <div>
                                        <input className ="inp" type="text" placeholder="Name"/>
                                    </div>
                                    <div>
                                        <input className ="inp" type="email" placeholder="Email"/>
                                    </div>
                                    <div>
                                        <input className ="inp" type="text" placeholder="Phone Number"/>
                                    </div>
                                    <div class="">
                                        <input className ="inp" type="text" placeholder="Message"/>
                                    </div>
                                    <div class="mt-5">
                                        <button type="submit" className='bus'>Send</button>
                                    </div>
                                    </div>

                                </div>

                                </form>
                            </div>
                            <div class="col-md-5">
                                <div class="map-box">
                                <div id="map">
                                    <div class="map-responsive">
                                    <iframe
                                        src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA0s1a7phLN0iaD6-UE7m4qP-z21pH0eSc&q=Eiffel+Tower+Paris+France"
                                        width="600" height="300" frameborder="0" id="frma" allowfullscreen></iframe>
                                    </div>
                                </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        </div>
                        <div className='soci'>
                            <div className='soci-f'>
                                <img src="./images/telephone.png"/>
                                <p>
                                    +09 9874563210
                                </p>
                            </div>
                            <div className='soci-f'>
                                <img src="./images/envelope.png"/>
                                <p>
                                    Demo@gmail.com
                                </p>
                            </div>
                            <div className='soci-f'>
                                <img src="./images/location.png"/>
                                <p>
                                    Location will be distracted by the readable
                                </p>
                            </div>
                            
                              


                        </div>


                    </section>
                        
            
                 <Footer />
            </>
             
        )
    }
}
export default Contact;

