import './home.css';
import React,{Component } from 'react';
import Footer from './Footer';


class HomeComponent extends Component{


    render(){
        return(
            <>
            <div class="main-con">
                <div className='containers'>
                    <div className='content1'>
                        <h1>FINANCIAL <br />SERVICE</h1>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has<br/> been the industry's standard dummy text ever</p>
                        <div className='buton'>
                            <button type="button" class="btn btn-outline-danger"  >Read More</button>
                            <button type="button" class="btn btn-outline-dark" >Contact Us</button>
                        </div>
                    </div>
                    <div className='content2'>
                            <img src ="./images/banner-img.png"/>
                    </div>
                </div>
                <div className='content3'>
                    <div>
                        <h1>WELCOME TO FINANCIAL SERVICES</h1>
                         <p>It is a long established fact that a reader will
                         be distracted by the readable<br/> content of a page when 
                         looking at its layout. The point of using Lorem Ipsum is that <br/> 
                         it has a more-or-less normal distribution of letters, as opposed 
                         to using 'Content<br/>  here, content here', making it</p>

                         <button type="button" class="btn btn-outline-danger"  >Read More</button>
                    </div>
                    <div>
                        <img src='./images/img-1.png'/>

                    </div>
                </div>
                <div className='content5'>
                    <div className='content5'>
                        <h1>WHAT WE DO</h1>
                        <p>It is a long established fact that a reader will be distracted by the readable content of a</p>
                    </div>
                    <div className='body5'>
                        <div className='main-content'> 
                            <img src="./images/icon-1.png" alt ="icon"/>
                            <h5>ACCOUNTING</h5>
                            <p>Lorem Ipsum is simply dummy text of the printing and</p>
                            <button type="button" class="btn btn-outline-danger"  >Read More</button>
                        </div>
                        <div className='main-contents'>
                            <img src="./images/icon-2.png" alt ="icon"/>
                            <h5>ADVISOR</h5>
                            <p>Lorem Ipsum is simply dummy text of the printing and</p>
                            <button type="button" class="btn btn-outline-danger"  >Read More</button>
                        </div>
                        <div className='main-content'>
                            <img src="./images/icon-3.png" alt ="icon"/>
                            <h5>INVESTMENT</h5>
                            <p>Lorem Ipsum is simply dummy text of the printing and</p>
                            <button type="button" class="btn btn-outline-danger"  >Read More</button>
                        </div>
                        <div className='main-content'>
                            <img src="./images/icon-4.png" alt ="icon"/>
                            <h5>FINANCIAL</h5>
                            <p>Lorem Ipsum is simply dummy text of the printing and</p>
                            <button type="button" class="btn btn-outline-danger"  >Read More</button>
                        </div>          
                    </div>
                </div>
                <div className='content4'>
                    <div className='body4'>
                        <div>
                            <img src="./images/icon-3.png" alt ="picture"/>
                            <h1>1000+</h1>
                            <h3>Years of Business</h3>
                        </div>
                        <div>
                            <img src="./images/icon-4.png" alt ="picture"/>
                            <h1>20000+</h1>
                            <h3>Project Delivered</h3>
                        </div>
                        <div>
                            <img src="./images/icon-2.png" alt ="picture"/>
                            <h1>10000+</h1>
                            <h3>Customer</h3>
                        </div>
                        <div>
                            <img src="./images/icon-1.png" alt ="picture"/>
                            <h1>1500+</h1>
                            <h3>Services</h3>
                        </div>
                        
                    </div>
                </div>
               
            </div>awda
              <div><Footer /></div>  
                    
            </>
        
           
        )
    }
}
export default HomeComponent;


