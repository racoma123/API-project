import axios from 'axios';
import React,{Component } from 'react';
import './login.css';
import Footer from './Footer';
import AllUserComponent from './AllUserComponent';
import Googlelogin from './GoogleLogin';

class Login extends Component{

    constructor(){
        super();
        this.state={ 
            "email" :'',
            "password" :' ',
         
        }
    }

    email=(event)=>{
        this.setState({
            email:event.target.value
            })
        }
        password=(event)=>{
            this.setState({
                password:event.target.value
            })
        }

    login=(event)=>{
        axios.post('login-pro',this.state)
        .then(res=>{
            console.log(res.data);
            <AllUserComponent/>
            
        })
        .catch(error=>{
            console.log(error);
        })
    }   

    render(){
        return (
            <div>
                    <div className='content12'>
                        <div>
                            <img src='./images/ofi.png' aalt="picture"/>

                        </div>
                        <div className='login1'>
                            <h1>Sign In </h1>
                            <p>Welcome back! Sign in to start hiring<br/>and managing your employees.</p>
                            <form onSubmit={this.login}> 
                                <label htmlFor ="email"> EMAIL ADDRESS :</label> <br />
                                <input type="email" value={this.state.email} onChange={this.email} /><br/>                  
                                <label htmlFor ="password">  PASSWORD :</label> <br />
                                <input type="password" value={this.state.password} onChange={this.password} /><br/>

                               
                                <input type="checkbox" id="vehicle1"  value="Terms"/>
		  						<label Htmlfor="vehicle1"> Remember Me </label>
                                  <span id="spants">Forget Password?</span>
                                <button type="submit">Login Now</button>
                                
                            </form>

                            <div className='Or'>
                                <p>Or </p>
                                <hr></hr>
                                <p>Login In Using Facebook</p>

                            </div>
                            <a href="/login" class="login-button">
                                <img src="./images/fb-icon1.png" alt="Facebook Logo" className="facebook-logo"/>
                                 Login with Facebook
                            </a>
                            <p>Don't have an account? <span id="spant">Register</span></p>
                            {/* <Googlelogin /> */}
                            
                           
                            
                        </div>
                  </div>
                <Footer />
            </div>
        )
    }


}
export default Login;