import axios from 'axios';
import React,{Component } from 'react';

class Webhook extends Component{

    constructor(){
        super();
        this.state={ 
            "text" :'',
        }
    }

    textInput=(event)=>{
        this.setState({
            text:event.target.value
            })
        }

    message=(event)=>{
            alert(this.state.text+" has been sent ");
            axios.post('/messages/D05AA921K2L',this.state)
            .then(res=>{
                console.log(res.data);
            })
            .catch(error=>{
                console.log(error);
            })
    }  

    render(){
        return(
            <div>
            <h1>Message Now </h1>
            <form onSubmit={this.message}> 

                <label htmlFor ="text"> message :</label> <br />
                 <input type="text" value={this.state.text} onChange={this.textInput} /><br/>                  

                <br/>
                <button type="submit">Send</button>
            </form>
        </div>
        )
    }
}
export default Webhook;
