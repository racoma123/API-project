import React,{Component } from 'react';

//Data from other Component {datafromap}
class AllUserComponent extends Component{

    render(){
        const mydata=this.props.alldata;
        const pheader=<tr><th>User Id</th> <th> Name</th> <th>username</th><th>Email</th><th> Password </th></tr>;

       const pdata=mydata.map((users,key)=><tr><td>{users.id}</td><td>{users.name}</td><td>{users.userName}</td><td>{users.email}</td><td>{users.password}</td></tr>);
        return (
         <div>
          <h1>Show All Products </h1>
          <table border="1">{pheader}{pdata}</table>
         </div>
        )
    }


}

export default AllUserComponent;