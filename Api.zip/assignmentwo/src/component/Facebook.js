import React,{Component } from 'react';
import FacebookLogin from 'react-facebook-login';
class Facebook extends Component
{
/*
    handleLogin = () => {
        window.location.href = 'http://localhost:9091/login';
      };
    
      render() {
        return (
          <div>
            <button onClick={this.handleLogin}>Login with Facebook</button>
          </div>
        );
      }*/

      constructor(props) {
        super(props);
        this.state = {
          username: ''
        };
      }
    
      responseFacebook = (response) => {
        if (response.status !== 'unknown') {
          const { name } = response;
          this.setState({ username: name });
        } else {
          console.log('Login failed');
        }
      };
    
      render() {
        const { username } = this.state;
    
        return (
          <div>
            <FacebookLogin
              appId="1239847529904132"
              autoLoad={false}
              fields="name,email,picture"
              callback={this.responseFacebook}
            />
            {username && <p>Welcome, {username}!</p>}
          </div>
        );
      }


}
export default Facebook;