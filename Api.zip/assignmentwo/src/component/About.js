import React,{Component } from 'react';
import './about.css';
import Footer from './Footer';

class About extends Component{
    render(){
        return(
            <>  
            <div className='Main-About'>
             <h1>About Us</h1>
                 <div className='About'>
                    <div>
                        <img src="./images/istockphoto-1207861966-612x612.jpg" alt ="travel"/>
                    </div>
                    <div> 
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin
                             literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney 
                             College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage,
                              and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem 
                              Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil)
                               by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the
                                Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in 
                                section 1.10.32</p>
                                <p>ntrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin
                             literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney 
                             College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage,
                              and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem 
                              Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil)
                               by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the
                                Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in 
                                section 1.10.32</p>

                    </div>
                 </div>
                 <div className='Mission'>
                       <h2>Our Mission & Vision</h2> 
                       <p>
                            <span className='spa'>Our Visions</span><br/>
                            <br/>
                            To become the leading construction firm, while delivering projects that consistently exceed international standards and provide
                             exceptional customer satisfaction.
                            To continually deliver excellent value <br/>& innovative construction solutions to meet our clients' requirements.
                            Using modern principles and sophisticated technologies, Alamiah Building Company envisions being the primary<br/> preference at all 
                            times both nationally and globally, for their renowned excellence, quality, performance and reliability in all types of constructions.
                            <br/><span className='spa'>Our Missions</span><br/>
                            <br/>
                            To be a leading construction company in the global market.
                            To become the customers' most preferred choice by attaining excellence in quality and timely completed value added projects.
                            To<br/> provide the highest level of service in the construction industry while offering superior craftsmanship to every project, we handle.
                            To continually innovate, develop and adopt <br/>state-of-the-art technology in methods and materials to enhance productivity and cost effectiveness.
                            To continually improve the competence of our team,<br/> and employ diverse, innovative & results-oriented personals, motivated to deliver excellence.
                            To build a safety culture aimed at continually<br/> reducing the frequency severity rate towards achieving zero accidents.
                            To identify and mitigate all the environmental<br/> impacts arising from our activities, and comply with applicable environmental norms.</p>
                 </div>
                 <div className='Journey'>
                        <h2>Journey Collection</h2>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, <br/>or randomised words which don't look even slightly believable</p>
                        <div className='Journey-grid'>
                            <div>
                                <img src="./images/j1.jpg"/>
                            </div>
                            <div>
                            <img src="./images/j2.jpg"/>
                           
                            </div>
                            <div>
                            <img src="./images/j4.jpg"/>
                            </div>
                            <div>
                            <img src="./images/j5.jpg"/>
                            </div>  
                            <div>
                            <img src="./images/j6.jpg"/>
                            </div>                                              
                            <div>
                            <img src="./images/j7.jpg"/>
                            </div>
                        </div>
                 </div>
                 </div>
                 <Footer />
            </>
             
        )
    }
}
export default About;

