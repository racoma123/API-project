import './footer.css';
import React,{Component } from 'react';


function Footer(){

    return(

    <>
        <div className='mainss'>
            <div className='Footer'>
                <div className='first'>
                <h2>About Us</h2>
                        <div className='hey'>
                            <div>
                                <img src="./images/map-icon.png" alt ="icon" />
                            </div>
                            <div>
                                <p>Locations</p>
                            </div>
                        </div>
                        <div className='hey'>
                            <div>
                                <img src="./images/call-icon.png" alt ="icon" />
                            </div>
                            <div>
                                <p>+01 9876543210</p>
                            </div>
                        </div>
                        <div className='hey'>
                            <div>
                                <img src="./images/map-icon.png" alt ="icon" />
                            </div>
                            <div>
                                <p>demo@gmail.com</p>
                            </div>
                        </div>
                </div>
                <div className='first'>
                    <h2>About Financial</h2>
                    <p>ipsum dolor sit amet, <br/>consectetur adipiscing elit, <br/> sed do eiusmod tempor <br/> incididunt</p>
                </div>
                <div className='first'>
                     <h2>Instagram</h2>
                     <div className='insta'>
                        <div className='insta1'>
                            <img src="./images/img-12.png"/>
                        </div>
                        <div>
                          <img src="./images/img-12.png"/>
                        </div>
                     </div>
                     <div className='insta'>
                        <div className='insta1'>
                            <img src="./images/img-12.png"/>
                        </div>
                        <div>
                          <img src="./images/img-12.png"/>
                        </div>
                     </div>
                     <div className='insta'>
                        <div className='insta1'>
                            <img src="./images/img-12.png"/>
                        </div>
                        <div>
                          <img src="./images/img-12.png"/>
                        </div>
                     </div>
                </div>
                <div className='first'>
                    <h2>Newsletter</h2>
                    <input type="text" class="mail_text" placeholder="Enter your email" name="Enter your email" />
                     <div className='Sub'>Subscribe
                     </div>
                     <div className='heys'>
                        <div className='social'><img src="./images/fb-icon1.png"/></div>
                        <div className='social'><img src="./images/twitter-icon1.png"/></div>
                        <div className='social'><img src="./images/linkedin-icon1.png"/></div>
                        <div className='social'><img src="./images/youtub-icon1.png"/></div>
            
    


                     </div>

                </div>
                </div>  
            </div>

    </>
      
    )
  }


export default Footer;