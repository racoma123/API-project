import axios from 'axios';
import React,{Component } from 'react';
import './registration.css';
import Footer from './Footer';

class Registration extends Component{
    //attibutes & methods 
    constructor(){
        super();
        this.state={    
            "name" : ' ',
            "userName" : ' ',
            "email" : ' ',
            "password" :''
        }
    }
name=(event)=>{
    this.setState({
        name:event.target.value
        
    })
}
userName=(event)=>{

    this.setState({
        userName:event.target.value
    })
}
email=(event)=>{
this.setState({
    email:event.target.value
    })
}
password=(event)=>{
    this.setState({
        password:event.target.value
    })
}
addUser=(event)=>{
    alert(this.state.name+" "+this.state.userName+" "+this.state.email+" "+this.state.password);
    axios.post('addUser',this.state)
    .then(res=>{
        console.log(res.data);
    })
    .catch(error=>{
        console.log(error);
    })
}
    //View --HTML
    render(){
        return (
    <div>
        <div className='content8'>
            <div className='info1'>
                <h1>INFORMATION</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do <br/>
						eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim <br/>
						ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut <br/>
						aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit <br/>
						in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur<br/>
						 sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt <br/>
						 mollit anim id est laborum.</p>
						 <h3>EUL ELECTT</h3>
						 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do <br/>
						eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim <br/>
						ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut <br/>
						</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do <br/>
						eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim <br/>
						ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut </p><br/>
						<button>Have An Account</button>	

            </div>
                    <div className='info2'>

                        <h1>Registration </h1>
                        <h5>It's Completely Free</h5>
                        <form onSubmit={this.addUser}> 
                            <label htmlFor ="name"> NAME:</label> <br />
                            <input type="text" value={this.state.name} onChange={this.name}/><br/>
                            <label htmlFor ="userName"> USERNAME :</label> <br />
                            <input type="text" value={this.state.userName} onChange={this.userName}/><br/>                    
                            <label htmlFor ="email"> EMAIL ADDRESS :</label> <br />
                            <input type="text" value={this.state.email} onChange={this.email}/><br/>                  
                            <label htmlFor ="password">  PASSWORD :</label> <br />
                            <input type="password" value={this.state.password} onChange={this.password} /><br/>
                          
                            <input type="checkbox" id="vehicle1"  value="Terms"/>
		  						<label Htmlfor="vehicle1"> I agree to the <span id="spant">Privacy Policy</span> and <span id="spant">Terms Of Use</span></label><br/>
                            <button type="submit">REGISTER NOW</button>
                            <p>Already Have An Account?</p>
                            <p className='log'>Login Now</p>
                        </form>
                    </div>

        </div>
       
        <Footer/>
    </div>

            
        )
    }
}

export default Registration;