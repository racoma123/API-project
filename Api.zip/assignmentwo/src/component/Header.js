import './header.css';
import React,{Component } from 'react';
import {BrowserRouter , Routes,Route ,Link} from "react-router-dom";
import Registration from './Registration';
import HomeComponent from './HomeComponent';
import Login from './Login';
import About from './About';
import Contact from './Contact';
import GoogleLogin from './GoogleLogin';



class Header extends Component{
    render(){
        return(
            <>
        <BrowserRouter>
            <nav>
                 <img src="./images/logo.png" alt ="logo" className="logo"/>
                 <ul>
                    <li> <Link to ="/" className='link' >Home</Link> </li>
                    <li> <Link to ="About" className='link' >About</Link> </li>
                    <li> <Link to ="Contact" className='link' >Contact</Link> </li>
                    <li><Link to ="register" className='link'>Registration</Link> </li>
                    <li> <Link to ="Login" className='link' >Login</Link> </li>
                    <li> <Link to ="google" className='link' >Google</Link> </li>
                </ul>
            </nav>
            <div>
                <Routes className ="links">
                    
                    <Route  path ="/" element ={<HomeComponent />}/>
                    <Route  path ="/register" element ={<Registration />}/>
                    <Route  path ="/About" element ={<About />}/>
                    <Route  path ="/Contact" element ={<Contact />}/>
                    <Route  path ="/Login" element ={<Login />}/>
                    <Route  path ="/google" element ={<GoogleLogin />}/>

                </Routes>

            </div>
         </BrowserRouter>
            </>
             
        )
    }
}
export default Header;


