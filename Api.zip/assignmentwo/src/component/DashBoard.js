import React,{Component } from 'react';


class DashBoard extends Component{
    render(){
        return(
            <>                    
               <h1>DashBoard</h1>       
            </>
             
        )
    }
}
export default DashBoard;

